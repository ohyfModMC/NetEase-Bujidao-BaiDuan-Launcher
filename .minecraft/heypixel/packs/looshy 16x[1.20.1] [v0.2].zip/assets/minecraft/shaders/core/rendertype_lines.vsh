#version 150

in vec3 Position;
in vec4 Color;
in vec3 Normal;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform vec2 ScreenSize;

out float vertexDistance;
out vec4 vertexColor;

// 定义不同类型线条的宽度
const float DEFAULT_LINE_WIDTH = 2.0; 
const float COLLISION_BOX_WHITE_WIDTH = 2;         // 碰撞箱线条(白色部分)的宽度
const float COLLISION_BOX_RED_WIDTH = 0;      // 碰撞箱线条(红色部分)的宽度
const float COLLISION_BOX_BLUE_WIDTH = 0;     // 碰撞箱线条(蓝色部分)的宽度
const float FISHING_ROD_LINE_WIDTH = 3;    // 鱼竿线条的宽度

const float VIEW_SHRINK = 1.0 - (1.0 / 256.0);
const mat4 VIEW_SCALE = mat4(
    VIEW_SHRINK, 0.0,        0.0,        0.0,
    0.0,        VIEW_SHRINK, 0.0,        0.0,
    0.0,        0.0,        VIEW_SHRINK, 0.0,
    0.0,        0.0,        0.0,        1.0
);

void main() {
    // 计算线条的起点和终点位置
    vec4 linePosStart = ProjMat * VIEW_SCALE * ModelViewMat * vec4(Position, 1.0);
    vec4 linePosEnd = ProjMat * VIEW_SCALE * ModelViewMat * vec4(Position + Normal, 1.0);

    // 将裁剪空间坐标转换为标准化设备坐标（NDC）
    vec3 ndc1 = linePosStart.xyz / linePosStart.w;
    vec3 ndc2 = linePosEnd.xyz / linePosEnd.w;

    // 计算线条在屏幕空间的方向
    vec2 lineScreenDirection = normalize((ndc2.xy - ndc1.xy) * ScreenSize);

    // 根据线条类型设置不同的线条宽度
    float currentLineWidth;
    if (Color == vec4(0.0, 0.0, 0.0, 1.0)) {
        // 鱼竿线条
        currentLineWidth = FISHING_ROD_LINE_WIDTH;
    }
    else if (Color == vec4(1.0, 1.0, 1.0, 1.0)) {
        // 碰撞箱(白色部分)线条
        currentLineWidth = COLLISION_BOX_WHITE_WIDTH;
    }
    else if (Color == vec4(1.0, 0.0, 0.0, 1.0)) {
        // 碰撞箱(红色部分)线条
        currentLineWidth = COLLISION_BOX_RED_WIDTH ;
    }
    else if (Color == vec4(0.0, 0.0, 1.0, 1.0)) {
        // 碰撞箱(蓝色部分)线条
        currentLineWidth = COLLISION_BOX_BLUE_WIDTH;
    }
    else {
        // 其他线条，使用默认宽度
        currentLineWidth = DEFAULT_LINE_WIDTH;
    }

    // 计算线条的偏移量
    vec2 lineOffset = vec2(-lineScreenDirection.y, lineScreenDirection.x) * currentLineWidth / ScreenSize;

    // 确保偏移方向一致，避免闪烁
    if (lineOffset.x < 0.0) {
        lineOffset *= -1.0;
    }

    // 根据顶点 ID 设置线条的两个端点偏移
    if (gl_VertexID % 2 == 0) {
        gl_Position = vec4((ndc1 + vec3(lineOffset, 0.0)) * linePosStart.w, linePosStart.w);
    }
    else {
        gl_Position = vec4((ndc1 - vec3(lineOffset, 0.0)) * linePosStart.w, linePosStart.w);
    }

    // 计算顶点到摄像机的距离（可用于后续处理）
    vertexDistance = length((ModelViewMat * vec4(Position, 1.0)).xyz);

    // 设置颜色：根据线条类型设置不同颜色
    vec4 temp = Color;
    if (Color == vec4(0.0, 0.0, 0.0, 1.0)) {
        temp = vec4(0.00, 0.00, 0.00, 1.0); // 鱼竿线条颜色
    }
    else if (Color == vec4(1.0, 1.0, 1.0, 1.0)) {
        temp = vec4(1.00, 1.00, 1.00, 1.0); // 碰撞箱线条(白色部分)颜色
    }
    else if (Color == vec4(1.0, 0.0, 0.0, 1.0)) {
        temp = vec4(1.00, 0.00, 0.00, 0.0); // 碰撞箱线条(红色部分)颜色
    }
    else if (Color == vec4(0.0, 0.0, 1.0, 1.0)) {
        temp = vec4(0.00, 0.00, 1.00, 1.0); // 碰撞箱线条(蓝色部分)颜色
    }
    // 其他线条保持原色
    vertexColor = temp;
}